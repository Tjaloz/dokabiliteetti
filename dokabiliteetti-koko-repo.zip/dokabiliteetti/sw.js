var CACHE_NAME = "dokabiliteetti-v38";
var ASSETS = [
  "./",
  "./index.html",
  "./tietosuoja.html",
  "./opas.html",
  "./styles.css",
  "./js/app.js",
  "./js/core.js",
  "./js/i18n.js",
  "./js/admin.js",
  "./js/juomat.js",
  "./js/booli.js",
  "./js/drinkki.js",
  "./js/csv.js",
  "./js/share-image.js",
  "./firebase-config.js",
  "./manifest.json",
  "./robots.txt",
  "./sitemap.xml",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.addAll(ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (key) { return key !== CACHE_NAME; })
            .map(function (key) { return caches.delete(key); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", function (event) {
  if (event.request.method !== "GET") return;
  // Älä välimuistita Firebase/Firestore-pyyntöjä - ne pitää aina hakea tuoreena
  if (event.request.url.indexOf(self.location.origin) !== 0) return;
  event.respondWith(
    caches.match(event.request).then(function (cached) {
      return cached || fetch(event.request).then(function (response) {
        var copy = response.clone();
        caches.open(CACHE_NAME).then(function (cache) {
          cache.put(event.request, copy);
        });
        return response;
      }).catch(function () {
        return cached;
      });
    })
  );
});
